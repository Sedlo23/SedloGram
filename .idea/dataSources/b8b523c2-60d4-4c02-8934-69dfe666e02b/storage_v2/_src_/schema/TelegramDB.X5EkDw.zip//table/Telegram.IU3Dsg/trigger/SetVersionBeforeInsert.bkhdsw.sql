create definer = doadmin@`%` trigger SetVersionBeforeInsert
    before insert
    on Telegram
    for each row
BEGIN
    -- Check if version is not provided
    IF NEW.version IS NULL THEN
        -- Directly set the version based on the maximum version found
        SET NEW.version = (SELECT COALESCE(MAX(version), 0) FROM Telegram 
                           WHERE NID_C = NEW.NID_C 
                             AND N_PIG = NEW.N_PIG 
                             AND NID_BG = NEW.NID_BG 
                             AND M_MCOUNT = NEW.M_MCOUNT) + 1;
    END IF;
END;

