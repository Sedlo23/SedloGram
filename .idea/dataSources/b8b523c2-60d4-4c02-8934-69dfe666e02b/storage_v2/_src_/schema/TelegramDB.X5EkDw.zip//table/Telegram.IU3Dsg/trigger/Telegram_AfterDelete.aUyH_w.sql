create definer = doadmin@`%` trigger Telegram_AfterDelete
    after delete
    on Telegram
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Telegram', 'DELETE', OLD.telegramID, CONCAT('Deleted record with telegramID = ', OLD.telegramID));
END;

