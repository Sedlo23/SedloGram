create
    definer = doadmin@`%` function BinaryStringToInt(binaryStr varchar(830)) returns int deterministic
BEGIN
    RETURN CONV(binaryStr, 2, 10);
END;

