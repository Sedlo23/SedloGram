create definer = doadmin@`%` trigger Telegram_BeforeInsert
    before insert
    on Telegram
    for each row
BEGIN
    SET NEW.crc32 = CRC32(NEW.encoded);
    -- Add your other logic here
END;

