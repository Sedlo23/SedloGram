create definer = doadmin@`%` trigger Ownership_AfterInsert
    after insert
    on Ownership
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Ownership', 'INSERT', NEW.ownershipID, CONCAT('Inserted record with ownershipID = ', NEW.ownershipID));
END;

