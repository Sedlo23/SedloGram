create definer = doadmin@`%` trigger Ownership_AfterDelete
    after delete
    on Ownership
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Ownership', 'DELETE', OLD.ownershipID, CONCAT('Deleted record with ownershipID = ', OLD.ownershipID));
END;

