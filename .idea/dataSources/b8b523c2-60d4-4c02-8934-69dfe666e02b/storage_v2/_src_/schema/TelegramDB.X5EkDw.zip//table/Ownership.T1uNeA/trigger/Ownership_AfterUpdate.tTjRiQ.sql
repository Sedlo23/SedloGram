create definer = doadmin@`%` trigger Ownership_AfterUpdate
    after update
    on Ownership
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Ownership', 'UPDATE', NEW.ownershipID, CONCAT('Updated record with ownershipID = ', NEW.ownershipID));
END;

