create definer = doadmin@`%` trigger Telegram_AfterInsert
    after insert
    on Telegram
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Telegram', 'INSERT', NEW.telegramID, CONCAT('Inserted record with telegramID = ', NEW.telegramID));
END;

