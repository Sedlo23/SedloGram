create definer = doadmin@`%` trigger Telegram_AfterUpdate
    after update
    on Telegram
    for each row
BEGIN
    INSERT INTO Changelog (tableName, operationType, recordID, details)
    VALUES ('Telegram', 'UPDATE', NEW.telegramID, CONCAT('Updated record with telegramID = ', NEW.telegramID));
END;

