create definer = doadmin@`%` trigger Telegram_BeforeUpdate
    before update
    on Telegram
    for each row
BEGIN
    SET NEW.Q_UPDOWN = BinaryStringToInt(SUBSTRING(NEW.decoded, 1, 1));  -- Starts at bit 1, length 1
    SET NEW.M_VERSION = BinaryStringToInt(SUBSTRING(NEW.decoded, 2, 7)); -- Starts at bit 2, length 7
    SET NEW.Q_MEDIA = BinaryStringToInt(SUBSTRING(NEW.decoded, 9, 1));   -- Starts at bit 9, length 1
    SET NEW.N_PIG = BinaryStringToInt(SUBSTRING(NEW.decoded, 10, 3));    -- Starts at bit 10, length 3
    SET NEW.N_TOTAL = BinaryStringToInt(SUBSTRING(NEW.decoded, 13, 3));  -- Starts at bit 13, length 3
    SET NEW.M_DUP = BinaryStringToInt(SUBSTRING(NEW.decoded, 16, 2));    -- Starts at bit 16, length 2
    SET NEW.M_MCOUNT = BinaryStringToInt(SUBSTRING(NEW.decoded, 18, 8)); -- Starts at bit 18, length 8
    SET NEW.NID_C = BinaryStringToInt(SUBSTRING(NEW.decoded, 26, 10));   -- Starts at bit 26, length 10
    SET NEW.NID_BG = BinaryStringToInt(SUBSTRING(NEW.decoded, 36, 14));  -- Starts at bit 36, length 14
    SET NEW.Q_LINK = BinaryStringToInt(SUBSTRING(NEW.decoded, 50, 1));   -- Starts at bit 50, length 1
END;

